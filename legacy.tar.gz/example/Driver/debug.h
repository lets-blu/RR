#ifndef __DEBUG_H__
#define __DEBUG_H__

#define DEBUG 

#endif // __DEBUG_H__
